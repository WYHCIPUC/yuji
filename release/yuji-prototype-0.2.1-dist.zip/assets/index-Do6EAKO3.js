(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))p(r);new MutationObserver(r=>{for(const o of r)if(o.type==="childList")for(const a of o.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&p(a)}).observe(document,{childList:!0,subtree:!0});function n(r){const o={};return r.integrity&&(o.integrity=r.integrity),r.referrerPolicy&&(o.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?o.credentials="include":r.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function p(r){if(r.ep)return;r.ep=!0;const o=n(r);fetch(r.href,o)}})();const i=[{id:"shangzhou",year:"商周",shortYear:"前 11 世纪—前 3 世纪",title:"天下先是一种秩序",description:"王畿居中，五服向外展开。世界被想象成一圈圈与中心相连的关系。",narrativeLine:"王者居中，甸侯绥要，层层向外。",certainty:"产品化叙事",source:"《尚书·禹贡》相关观念；首版为通俗化整理，非原文引号引用。",accent:"#c5a45b"},{id:"yujitu",year:"1136",shortYear:"南宋",title:"山川开始被量进格子",description:"河流、道路和地名逐渐成为可记录、可比较的形状。地图开始回答“它在哪里”。",narrativeLine:"画方百里，飞鸟取直。",certainty:"产品化叙事",source:"《禹迹图》及宋代地图学资料，具体表述待人工复核。",accent:"#b54832"},{id:"kunyu",year:"1602",shortYear:"明末",title:"天下终于有了弧度",description:"五大洲进入中国人的地图，熟悉的中心之外，出现了一个更大的地球。",narrativeLine:"熟悉的中心之外，出现了更大的地球。",certainty:"产品化叙事",source:"《坤舆万国全图》相关公开研究，具体表述待人工复核。",accent:"#88a79b"}],D=[{name:"燕京",modern:"北京",chain:["燕京","蓟城","大都","北平","北京"],era:"商周—明",note:"“燕京”与后来的北京并非每一时期都严格指同一城址，首版按常见历史称谓链展示。",certainty:"合理解释",source:"《史记·燕召公世家》；北京地方志公开资料"},{name:"大都",modern:"北京",chain:["燕京","蓟城","大都","北平","北京"],era:"元",note:"元大都为元代都城称谓，城市范围与今日北京城区不能直接等同。",certainty:"可确定事实",source:"《元史·地理志》"},{name:"北平",modern:"北京",chain:["燕京","蓟城","大都","北平","北京"],era:"明",note:"明代部分时期使用“北平”称谓，名称变化与行政建制有关。",certainty:"可确定事实",source:"《明史·地理志》"},{name:"会稽",modern:"绍兴一带",chain:["会稽","越州","绍兴"],era:"先秦—今",note:"古代会稽范围随行政区变化，不能简单等同今天的绍兴市。",certainty:"学术争议",source:"《汉书·地理志》；CHGIS 公开说明"},{name:"临安",modern:"杭州",chain:["钱唐","杭州","临安","杭州"],era:"南宋",note:"临安是南宋行在及相关行政区域的称谓。",certainty:"可确定事实",source:"《宋史·地理志》"},{name:"长安",modern:"西安一带",chain:["长安","京兆府","西安"],era:"汉—唐",note:"古代都城范围与现代城市行政边界不同。",certainty:"可确定事实",source:"《旧唐书·地理志》"},{name:"洛阳",modern:"洛阳",chain:["洛阳","东都","河南府","洛阳"],era:"先秦—今",note:"名称延续较长，但城市范围和行政层级不断变化。",certainty:"可确定事实",source:"《水经注》；《宋史·地理志》"},{name:"建康",modern:"南京",chain:["秣陵","建业","建康","江宁","南京"],era:"三国—明",note:"不同朝代的城址与行政范围并不完全一致。",certainty:"可确定事实",source:"《晋书·地理志》"},{name:"姑苏",modern:"苏州",chain:["吴县","姑苏","平江府","苏州"],era:"先秦—今",note:"姑苏既是地名，也常作为文化意象使用。",certainty:"合理解释",source:"《吴地记》相关公开整理"},{name:"成都",modern:"成都",chain:["成都","益州","成都府","成都"],era:"先秦—今",note:"成都名称延续较长，行政层级随时代变化。",certainty:"可确定事实",source:"《华阳国志》"},{name:"江陵",modern:"荆州一带",chain:["江陵","荆州","江陵","荆州"],era:"战国—今",note:"“荆州”有时指较大区域，不等同于单一城址。",certainty:"学术争议",source:"《汉书·地理志》"},{name:"襄阳",modern:"襄阳",chain:["襄阳","襄州","襄阳"],era:"汉—今",note:"古代襄阳与樊城等区域关系需结合时代理解。",certainty:"合理解释",source:"《元和郡县图志》"},{name:"邯郸",modern:"邯郸",chain:["邯郸","赵郡","磁州","邯郸"],era:"战国—今",note:"赵国都城邯郸是历史和现代地名的重叠案例。",certainty:"可确定事实",source:"《史记·赵世家》"},{name:"大梁",modern:"开封一带",chain:["大梁","汴州","东京","开封"],era:"战国—宋",note:"大梁与后来的开封存在历史延续关系，但范围不能直接画等号。",certainty:"合理解释",source:"《史记·魏世家》"},{name:"汴京",modern:"开封",chain:["大梁","汴州","汴京","开封"],era:"北宋",note:"北宋东京的城市范围和现代开封市范围不同。",certainty:"可确定事实",source:"《宋史·地理志》"},{name:"广州",modern:"广州",chain:["番禺","广州","广州"],era:"秦—今",note:"广州作为港口和行政地名的含义在不同时期有变化。",certainty:"可确定事实",source:"《汉书·地理志》"},{name:"交趾",modern:"越南北部一带",chain:["交趾","交州","安南"],era:"汉—唐",note:"这是古代行政与区域称谓，不能直接套用现代国界概念。",certainty:"学术争议",source:"《后汉书·郡国志》"},{name:"敦煌",modern:"敦煌",chain:["敦煌","沙州","敦煌"],era:"汉—今",note:"敦煌长期处在交通和文化交流通道上。",certainty:"可确定事实",source:"《汉书·地理志》"},{name:"凉州",modern:"甘肃中部一带",chain:["凉州","武威郡","凉州"],era:"汉—唐",note:"凉州多指较大区域，不能视作单一城市。",certainty:"合理解释",source:"《后汉书·郡国志》"},{name:"云中",modern:"呼和浩特西南一带",chain:["云中","云中郡","胜州"],era:"战国—唐",note:"古代郡名的边界和治所可能发生迁移。",certainty:"学术争议",source:"《汉书·地理志》"},{name:"琅琊",modern:"山东东南沿海一带",chain:["琅琊","琅琊郡","沂州"],era:"先秦—唐",note:"琅琊既可指郡，也可指山、地名或文化称谓。",certainty:"学术争议",source:"《史记·秦始皇本纪》"}],N=[{era:"shangzhou",name:"《禹贡》",role:"最早的天下想象",text:"天下以王畿为心。五百里甸服，五百里侯服，再往外，绥服、要服、荒服——秩序像水波一样，一层层推向无人知晓的远方。",source:"人物独白为基于《尚书·禹贡》五服观念的产品化整理，非原文引用。"},{era:"yujitu",name:"沈括",role:"北宋科学家 · 《梦溪笔谈》",text:"我画天下州县，取飞鸟之路为直——两地相距多远，要问天上的飞鸟，不问山路的曲折。山川从此可以被量进格子里。",source:"人物独白为基于《梦溪笔谈》及宋代地图学史料的产品化整理，非原文引用。"},{era:"kunyu",name:"利玛窦",role:"明末来华的制图者",text:"我把整个世界画成一个球，献给万历皇帝。从此，天圆地方之外，人们知道了海的尽头还有五大洲——天下有了弧度。",source:"人物独白为基于《坤舆万国全图》相关公开研究的产品化整理，非原文引用。"}],J=[{type:"古地图",title:"《禹迹图》沙畹摹绘本（1903）",status:"公有领域 · 已核验",detail:"原石刻 1136 年，藏西安碑林博物馆。摹绘本载 BEFEO 1903，扫描出自美国国会图书馆（g7821c.ct000285），共享资源标注 Public domain。"},{type:"古地图",title:"《华夷图》拓片（约 1903）",status:"公有领域 · 已核验",detail:"原石刻 1136 年，与《禹迹图》同石。拓片藏美国国会图书馆（2002626771），共享资源标注 Public domain。"},{type:"古地图",title:"《坤舆万国全图》（1602）",status:"公有领域 · 已核验",detail:"17 世纪刊本影像，日本东北大学附属图书馆狩野文库，共享资源标注 Public domain。"},{type:"古地图",title:"《武备志》郑和航海图 · 满剌加段",status:"公有领域 · 已核验",detail:"茅元仪《武备志》（17 世纪）航海图分段，共享资源标注 Public domain。"},{type:"文字",title:"《禹贡》《史记》《汉书》《宋史》等公开古籍整理",status:"需人工复核",detail:"古籍为历史来源，网页中的现代标点、译释和解释需要单独记录来源。"},{type:"示意",title:"时代区域和河流简化图层",status:"产品化演绎",detail:"为帮助理解而绘制，不作为精确 GIS 数据或现实边界主张。"}],I=[{name:"洛阳",x:454,y:238},{name:"建康",x:520,y:280},{name:"临安",x:600,y:315},{name:"燕京",x:715,y:260},{name:"长安",x:330,y:242},{name:"敦煌",x:205,y:170},{name:"广州",x:645,y:396}].map(e=>({...e,hit:26})),_={shangzhou:"服制",yujitu:"郡县",kunyu:"地圆"},Q={服制:"以中心向外层层展开，天下首先是一种关系秩序。",郡县:"世界被分成可以管理、丈量和征调的地方单元。",地圆:"大地不再有边缘，而是一个可以绕行一周的球体。"},B={shangzhou:"商",yujitu:"宋",kunyu:"明"},ee={yujitu:{src:"assets/maps/yujitu-befeo-1903.jpg",caption:"《禹迹图》沙畹摹绘本 · 1903 · 公有领域",x:130,y:62,w:391,h:440,cx:130,cy:524},kunyu:{src:"assets/maps/kunyu-wanguo-1602.jpg",caption:"《坤舆万国全图》 · 1602 · 公有领域",x:150,y:118,w:730,h:328,cx:150,cy:472}},R=document.querySelector("#app");if(!R)throw new Error("App root not found");const b=Number(localStorage.getItem("yuji-era")??0);let s=Number.isFinite(b)&&b>=0&&b<i.length?b:0,g=.55,j=!1,z="";function V(e){return N.find(t=>t.era===e)??N[0]}function Y(e){return e.replace(/[《》]/g,"").charAt(0)}const S=V(i[s].id);R.innerHTML=`
  <div class="app-shell" data-era="${i[s].id}">
    <div class="grain" aria-hidden="true"></div>
    <header class="topbar">
      <a class="brand" href="#" aria-label="禹迹首页"><span class="brand-mark">禹</span><span>禹迹</span></a>
      <div class="topbar-meta"><span class="eyebrow">历史地理交互叙事 · 原型 0.2.1</span><button class="text-button" id="open-sources">来源与说明</button></div>
    </header>

    <main>
      <section class="intro-screen" id="intro-screen" aria-labelledby="intro-title">
        <div class="intro-rings" aria-hidden="true">
          <span style="--ring: 1; --lx: 61%; --ly: 39%"><i>甸</i></span>
          <span style="--ring: 2; --lx: 67%; --ly: 33%"><i>侯</i></span>
          <span style="--ring: 3; --lx: 73%; --ly: 27%"><i>绥</i></span>
          <span style="--ring: 4; --lx: 79%; --ly: 21%"><i>要</i></span>
          <span style="--ring: 5; --lx: 85%; --ly: 15%"><i>荒</i></span>
        </div>
        <p class="kicker">从想象到测量 · 公元前 11 世纪—1602 年</p>
        <h1 id="intro-title">何谓天下？</h1>
        <p class="intro-copy">拖动时间轴，看古人眼中的世界<br class="mobile-only" />如何一点点长成地球。</p>
        <button class="primary-button" id="start-button"><span>开始探索</span><span class="arrow">→</span></button>
        <button class="resume-button" id="resume-button" hidden>继续上次看到的时代</button>
        <button class="skip-button" id="skip-intro">跳过开场动画</button>
      </section>

      <section class="experience" id="experience" aria-label="时间轴探索">
        <div class="scene-header">
          <div>
            <p class="kicker"><i class="era-accent-dot" id="era-accent-dot"></i>当前时代 · <span id="era-short-year">${i[s].shortYear}</span></p>
            <h2 id="era-title" aria-live="polite">${i[s].title}</h2>
            <p id="era-description" aria-live="polite">${i[s].description}</p>
            <p class="scene-source" id="era-source">内容状态：${i[s].certainty} · ${i[s].source}</p>
          </div>
          <div class="scene-actions">
            <button class="quiet-button" id="toggle-play" aria-label="播放时间轴" title="自动播放三幕时代演变"><span class="play-icon">▶</span><span>播放</span></button>
            <button class="quiet-button" id="reset-timeline" aria-label="重置时间轴" title="回到商周起点"><span class="reset-icon">↺</span><span>重置</span></button>
            <button class="quiet-button" id="open-search" title="按古今名称查询地名"><span class="search-icon">⌕</span><span>查地名</span></button>
          </div>
        </div>

        <div class="map-stage" id="map-stage">
          <div class="map-label map-label-north">北</div>
          <div class="map-seal" aria-hidden="true"><span>禹</span><span>跡</span></div>
          <div class="map-era-char" id="map-era-char" aria-hidden="true">${B[i[s].id]??""}</div>
          <p class="map-quote" id="map-quote">${i[s].narrativeLine}</p>
          <svg class="map-svg" viewBox="0 0 1000 600" role="img" aria-label="随时代变化的示意地图">
            <defs>
              <filter id="soft-glow"><feGaussianBlur stdDeviation="8"/></filter>
              <filter id="paper-grain" x="0" y="0" width="100%" height="100%">
                <feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" stitchTiles="stitch" result="noise"/>
                <feColorMatrix in="noise" type="matrix" values="0 0 0 0 0.55  0 0 0 0 0.47  0 0 0 0 0.36  0 0 0 .05 0"/>
              </filter>
              <linearGradient id="paper-gradient" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e6d0a4" stop-opacity=".97"/><stop offset="1" stop-color="#b8946a" stop-opacity=".88"/></linearGradient>
              <radialGradient id="paper-vignette" cx=".5" cy=".46" r=".75"><stop offset=".55" stop-color="#3b3a31"/><stop offset="1" stop-color="#26251f"/></radialGradient>
              <clipPath id="map-clip"><rect x="86" y="42" width="828" height="500" rx="8"/></clipPath>
            </defs>            <rect x="86" y="42" width="828" height="500" rx="8" class="map-paper" fill="url(#paper-vignette)"/>
            <g clip-path="url(#map-clip)">
              <rect x="86" y="42" width="828" height="500" filter="url(#paper-grain)"/>
              <rect class="ocean-wash" x="86" y="42" width="828" height="500"/>
              <path class="terra-incognita" d="M86 76 C146 56 186 104 168 168 C154 222 106 238 86 214 Z"/>
              <path class="terra-incognita" d="M820 448 C880 410 914 428 914 492 L914 542 L848 542 C822 512 802 476 820 448 Z"/>
              <path class="terra-incognita" d="M86 396 C132 380 164 416 154 470 C146 512 104 532 86 516 Z"/>
              <path class="terra-incognita" d="M560 42 C620 30 690 38 720 58 C688 78 610 84 566 70 C550 60 548 48 560 42 Z"/>
              <path class="mountain-haze haze-1" d="M40 430 C180 310 260 360 360 280 S570 180 720 300 S920 250 1050 360"/>
              <path class="mountain-haze haze-2" d="M60 500 C220 400 290 470 440 355 S670 270 940 430"/>
              <g class="wufu-rings">
                <circle cx="480" cy="290" r="250" class="ring-fill fill-5"/>
                <circle cx="480" cy="290" r="205" class="ring-fill fill-4"/>
                <circle cx="480" cy="290" r="155" class="ring-fill fill-3"/>
                <circle cx="480" cy="290" r="105" class="ring-fill fill-2"/>
                <circle cx="480" cy="290" r="55" class="ring-fill fill-1"/>
                <line x1="480" y1="290" x2="480" y2="55" class="ring-axis"/>
                <line x1="480" y1="290" x2="735" y2="290" class="ring-axis"/>
                <line x1="480" y1="290" x2="480" y2="525" class="ring-axis"/>
                <line x1="480" y1="290" x2="225" y2="290" class="ring-axis"/>
                <circle cx="480" cy="290" r="250" class="ring ring-5"/>
                <circle cx="480" cy="290" r="205" class="ring ring-4"/>
                <circle cx="480" cy="290" r="155" class="ring ring-3"/>
                <circle cx="480" cy="290" r="105" class="ring ring-2"/>
                <circle cx="480" cy="290" r="55" class="ring ring-1"/>
                <circle cx="480" cy="290" r="9" class="ring-core"/>
                <text x="480" y="252" class="ring-label">甸服</text>
                <text x="480" y="202" class="ring-label">侯服</text>
                <text x="480" y="152" class="ring-label">绥服</text>
                <text x="480" y="102" class="ring-label">要服</text>
                <text x="480" y="70" class="ring-label">荒服</text>
                <text x="480" y="322" class="ring-label ring-core-label">王畿</text>
              </g>
              <path class="mountain-range" d="M128 246 l20 -30 l20 30 M158 216 l16 -24 l16 24 M480 210 l22 -32 l22 32 M522 178 l18 -26 l18 26 M770 250 l20 -30 l20 30 M800 220 l16 -24 l16 24"/>
              <path class="grid-lines" d="M160 56V530 M240 56V530 M320 56V530 M400 56V530 M480 56V530 M560 56V530 M640 56V530 M720 56V530 M800 56V530 M880 56V530 M100 130H900 M100 210H900 M100 290H900 M100 370H900 M100 450H900"/>
              <path class="territory territory-west" d="M125 190 C170 118 262 106 332 146 C382 176 402 232 374 278 C342 322 262 338 200 316 C150 298 118 246 125 190 Z"/>
              <path class="territory territory-east" d="M428 172 C470 128 560 112 650 122 C700 128 742 118 764 142 C750 162 726 172 706 168 C700 192 718 216 744 226 C792 246 826 288 818 332 C806 388 748 420 680 414 C620 442 540 428 494 386 C452 348 408 300 402 248 C398 212 410 190 428 172 Z"/>
              <path class="river river-yellow" d="M185 150 C280 168 305 224 380 220 C465 215 510 160 602 184 C665 201 715 238 805 220"/>
              <path class="river river-yangtze" d="M195 300 C295 278 370 330 455 318 C545 305 604 350 680 337 C745 326 784 286 850 305"/>
              <path class="river river-future" d="M620 95 C690 150 718 188 720 235 C721 280 790 320 862 394"/>
              <g class="globe-curvature">
                <path class="globe-arc" d="M86 480 Q500 356 914 480"/>
                <path class="globe-arc" d="M86 138 Q500 20 914 138"/>
                <path class="globe-line" d="M240 42 Q296 292 240 542"/>
                <path class="globe-line" d="M370 42 Q424 292 370 542"/>
                <path class="globe-line" d="M500 42 Q556 292 500 542"/>
                <path class="globe-line" d="M630 42 Q682 292 630 542"/>
                <path class="globe-line" d="M760 42 Q808 292 760 542"/>
                <path class="globe-line" d="M86 176 Q500 146 914 176"/>
                <path class="globe-line" d="M86 296 Q500 268 914 296"/>
                <path class="globe-line" d="M86 412 Q500 384 914 412"/>
              </g>
              <g class="compass" transform="translate(152 462)">
                <circle r="26" class="compass-ring"/>
                <path d="M0 -19 L4 0 L0 19 L-4 0 Z" class="compass-needle"/>
                <path d="M-19 0 L0 -4 L19 0 L0 4 Z" class="compass-cross"/>
                <text y="-32" class="compass-n">子</text>
                <text y="42" class="compass-n">午</text>
              </g>
              <g class="map-places">${I.map(e=>`<g class="map-place" data-place="${e.name}" role="button" tabindex="0" aria-label="查询地名：${e.name}"><circle class="place-hit" cx="${e.x}" cy="${e.y}" r="${e.hit}"/><circle class="place-dot" cx="${e.x}" cy="${e.y}" r="8"/><text class="place-label" x="${e.x-16}" y="${e.y-16}">${e.name}</text></g>`).join("")}</g>
              <g class="ancient-overlay" id="ancient-overlay"><g class="overlay-real"><image id="overlay-image" class="overlay-image" x="130" y="62" width="391" height="440" preserveAspectRatio="xMidYMid meet" href="assets/maps/yujitu-befeo-1903.jpg"/><text id="overlay-caption" x="130" y="524" class="overlay-caption">《禹迹图》沙畹摹绘本 · 1903 · 公有领域</text></g></g>
            </g>
            <rect x="86" y="42" width="828" height="500" rx="8" class="map-frame"/>
          </svg>
          <div class="map-stamp">示意重绘<br />不代表现实边界</div>
          <button class="expand-button" id="expand-map" aria-label="放大查看地图" title="放大查看地图">⤢</button>
          <button class="compare-button" id="compare-button"><span class="compare-icon">◐</span><span>掀开古今对照</span></button>
          <div class="overlay-control" id="overlay-control" aria-hidden="true"><div class="overlay-panel"><div class="panel-heading"><div><p class="card-label">古今叠层</p><h3>掀开古图，对照今图</h3></div><button class="close-button" id="close-overlay" aria-label="关闭古今叠层">×</button></div><p>古图为已核验的公版原图（禹迹图 / 坤舆万国全图），与今图未做严格配准，仅作视觉叠合；方位与比例的真实差异本身就是历史。</p><label for="opacity-range">古图叠层 <output id="opacity-output">55%</output></label><input id="opacity-range" type="range" min="0" max="100" value="55"/><div class="panel-foot"><span>今图 · 现代示意</span><span>古图 · 禹迹图式</span></div></div></div>
        </div>

        <div class="timeline-wrap">
          <div class="timeline-heading"><span>时间轴 <i class="heading-seal" title="圭尺：古代量天之尺，此处喻指度量三千年时间的标尺">圭尺</i></span><span class="timeline-hint" id="timeline-hint">向右拖动，观察世界变得可测</span></div>
          <div class="timeline" id="timeline" role="slider" aria-label="时代时间轴" aria-valuemin="0" aria-valuemax="${i.length-1}" aria-valuenow="${s}" tabindex="0">
            <div class="timeline-track"><div class="timeline-progress" id="timeline-progress"></div></div>
            <div class="timeline-cursor" id="timeline-cursor" aria-hidden="true"><span class="cursor-knob"></span><span class="cursor-needle"></span></div>
            ${i.map((e,t)=>`<button class="timeline-node ${t===s?"is-active":""}" data-index="${t}" style="--node-accent:${e.accent}" aria-label="${e.year}：${e.title}"><span class="node-dot"></span><span class="node-year">${e.year}</span><span class="node-caption">${e.shortYear}</span></button>`).join("")}
          </div>
        </div>

        <div class="bottom-grid">
          <article class="story-card" id="story-card">
            <div class="card-label">制图者引路</div>
            <div class="story-content"><div class="story-avatar">${Y(S.name)}</div><div><h3>${S.name}<small class="story-role">${S.role}</small></h3><p>${S.text}</p><small class="story-source">${S.source}</small></div></div>
          </article>
          <article class="model-card"><div class="card-label">天下模型 · 示意</div><div class="model-switch" role="tablist"><button class="model-tab is-active" data-model="服制" role="tab" aria-selected="true">五服</button><button class="model-tab" data-model="郡县" role="tab" aria-selected="false">郡县</button><button class="model-tab" data-model="地圆" role="tab" aria-selected="false">地圆</button></div><p id="model-copy">以中心向外层层展开，天下首先是一种关系秩序。</p></article>
        </div>
      </section>
    </main>

    <footer class="site-footer">
      <span>禹迹 · 历史地理交互叙事原型 0.2.1</span>
      <span class="footer-note">内容为产品化整理，古图素材已核验公有领域</span>
    </footer>

    <div class="map-lightbox" id="map-lightbox" aria-hidden="true"><button class="close-button lightbox-close" id="close-lightbox" aria-label="关闭放大地图">×</button><p class="lightbox-hint">点按空白处关闭 · 示意重绘，不代表现实边界</p><div class="lightbox-body" id="lightbox-body"></div></div>

    <div class="search-drawer" id="search-drawer" aria-hidden="true"><div class="drawer-inner"><div class="panel-heading"><div><p class="card-label">地名查询</p><h3>查一个地名的前世</h3></div><button class="close-button" id="close-search" aria-label="关闭地名查询">×</button></div><label class="search-field"><span>输入古今名称</span><input id="place-search" type="search" placeholder="例如：燕京 / 北京" autocomplete="off"/><span class="search-key">${/Mac|iPhone|iPad/.test(navigator.platform)?"⌘ K":"Ctrl K"}</span></label><div class="search-suggestions" id="search-suggestions"></div><div class="search-results" id="search-results"></div></div></div>

    <div class="sources-drawer" id="sources-drawer" aria-hidden="true"><div class="drawer-inner"><div class="panel-heading"><div><p class="card-label">来源与说明</p><h3>每一条线，都有来处</h3></div><button class="close-button" id="close-sources" aria-label="关闭来源与说明">×</button></div><p class="drawer-intro">当前为原型数据。正式发布前，所有图片、字体、文字和配准成果都需要再次核验许可。</p><div class="source-list">${J.map(e=>`<article class="source-item"><div class="source-type">${e.type}</div><div><h4>${e.title}</h4><p>${e.detail}</p><span class="source-status">${e.status}</span></div></article>`).join("")}</div><div class="source-note"><strong>说明</strong><p>历史边界、地名对应和人物独白可能存在争议。产品会把确定事实、合理解释、学术争议和产品化演绎分开标记。</p></div></div></div>
  </div>
`;const te=document.querySelector(".app-shell"),Z=document.querySelector("#intro-screen"),G=document.querySelector("#experience"),ae=document.querySelector("#era-title"),se=document.querySelector("#era-description"),re=document.querySelector("#era-short-year"),ne=document.querySelector("#era-source"),ie=document.querySelector("#map-quote"),ce=document.querySelector(".story-avatar"),oe=document.querySelector(".story-content h3"),le=document.querySelector(".story-content p"),de=document.querySelector(".story-source"),ue=document.querySelector("#timeline-progress"),pe=document.querySelector("#timeline-cursor"),l=document.querySelector("#timeline"),w=document.querySelector("#ancient-overlay"),L=document.querySelector("#overlay-image"),E=document.querySelector("#overlay-caption");function q(e){return e===0?0:e===1?.55:.4}const m=document.querySelector("#overlay-control"),f=document.querySelector("#search-drawer"),P=document.querySelector("#sources-drawer"),u=document.querySelector("#place-search"),F=document.querySelector("#search-results"),K=document.querySelector("#search-suggestions");function d(e){var O;s=Math.max(0,Math.min(i.length-1,e));const t=i[s],n=V(t.id);te.dataset.era=t.id,ae.textContent=t.title,se.textContent=t.description,re.textContent=t.shortYear,ne.textContent=`内容状态：${t.certainty} · ${t.source}`,ie.textContent=t.narrativeLine,document.querySelector("#map-era-char").textContent=B[t.id]??"",document.querySelector("#era-accent-dot").style.background=t.accent,document.querySelector("#era-accent-dot").style.boxShadow=`0 0 10px ${t.accent}66`,ce.textContent=Y(n.name),oe.innerHTML=`${n.name}<small class="story-role">${n.role}</small>`,le.textContent=n.text,de.textContent=n.source;const p=s/(i.length-1),o=(O=document.querySelectorAll(".timeline-node")[s])==null?void 0:O.querySelector(".node-dot");let a=p*100;if(o){const y=o.getBoundingClientRect(),h=l.getBoundingClientRect();h.width>0&&(a=(y.left+y.width/2-h.left)/h.width*100)}const c=ee[t.id];c?(L.setAttribute("href",c.src),L.setAttribute("x",String(c.x)),L.setAttribute("y",String(c.y)),L.setAttribute("width",String(c.w)),L.setAttribute("height",String(c.h)),E.setAttribute("x",String(c.cx)),E.setAttribute("y",String(c.cy)),E.textContent=c.caption,w.classList.remove("is-off")):w.classList.add("is-off"),w.style.opacity=String(g*q(s)),ue.style.width=`${a}%`,pe.style.left=`${a}%`,l.setAttribute("aria-valuenow",String(s)),document.querySelectorAll(".timeline-node").forEach((y,h)=>y.classList.toggle("is-active",h===s)),document.querySelector("#timeline-hint").textContent=s===1?"山川被量进了格子，试试掀开古今对照":s===2?"世界打开了，地球开始有了弧度":"向右拖动，观察世界变得可测";const T=_[t.id]??"服制";document.querySelectorAll(".model-tab").forEach(y=>{const h=y.dataset.model===T;y.classList.toggle("is-active",h),y.setAttribute("aria-selected",String(h))}),document.querySelector("#model-copy").textContent=Q[T],localStorage.setItem("yuji-era",String(s))}function $(){j=!0,Z.classList.add("is-hidden"),G.classList.add("is-visible"),setTimeout(()=>l.focus({preventScroll:!0}),500)}function v(e,t){e.classList.toggle("is-open",t),e.setAttribute("aria-hidden",String(!t)),document.body.classList.toggle("drawer-open",t)}function M(e=""){const t=e.trim().toLowerCase(),n=D.filter(a=>!t||`${a.name}${a.modern}${a.chain.join("")}`.toLowerCase().includes(t)).map(a=>({place:a,rank:`${a.name}${a.modern}`.toLowerCase().includes(t)?0:1,exact:a.name===e.trim()})).sort((a,c)=>Number(c.exact)-Number(a.exact)||a.rank-c.rank),p=new Set,r=[];for(const a of n){const c=`${a.place.modern}|${a.place.chain.join("→")}`;if(!p.has(c)&&(p.add(c),r.push(a.place),r.length>=8))break}K.innerHTML=t?"":"<span>试试</span>"+D.slice(0,5).map(a=>`<button class="suggestion" data-place="${a.name}">${a.name}</button>`).join("");const o=new Set(I.map(a=>a.name));F.innerHTML=r.length?r.map(a=>`<article class="place-result" tabindex="0"><div class="place-heading"><h4>${a.name}</h4><span>${a.modern}</span></div><div class="place-chain">${a.chain.map(c=>`<span class="chain-item ${c===a.name?"is-current":""}">${c}</span>`).join("<i>→</i>")}</div><p>${a.note}</p><div class="place-meta"><span>${a.certainty}</span><span>${a.era}</span></div>${o.has(a.name)?`<button class="locate-button" data-locate="${a.name}"><span>◎</span>在图上定位</button>`:""}<small>来源：${a.source}</small></article>`).join(""):`<div class="empty-state"><span class="empty-mark">⌁</span><strong>还没有找到这个地名</strong><p>首版只收录 20 条示例地名，试试这些：</p><div class="empty-suggestions">${["燕京","临安","长安","大都"].map(a=>`<button class="suggestion" data-place="${a}">${a}</button>`).join("")}</div></div>`}function me(e){u.value=e,u.dispatchEvent(new Event("input")),u.focus()}document.querySelector("#start-button").addEventListener("click",$);document.querySelector("#skip-intro").addEventListener("click",$);const k=document.querySelector("#resume-button");b>0&&(k.hidden=!1,k.textContent=`继续上次看到的 ${i[b].year}`);k.addEventListener("click",()=>{d(s),$()});document.querySelector("#compare-button").addEventListener("click",()=>{m.classList.add("is-open"),m.setAttribute("aria-hidden","false"),g<.55&&(g=.55,document.querySelector("#opacity-range").value="55",w.style.opacity=String(g*Math.max(q(s),.85)),document.querySelector("#opacity-output").textContent="55%")});document.querySelector("#close-overlay").addEventListener("click",()=>{m.classList.remove("is-open"),m.setAttribute("aria-hidden","true"),d(s)});m.addEventListener("click",e=>{e.target===m&&(m.classList.remove("is-open"),m.setAttribute("aria-hidden","true"),d(s))});document.querySelector("#opacity-range").addEventListener("input",e=>{g=Number(e.target.value)/100;const n=m.classList.contains("is-open")?Math.max(q(s),.85):q(s);w.style.opacity=String(g*n),document.querySelector("#opacity-output").textContent=`${Math.round(g*100)}%`});document.querySelector("#open-search").addEventListener("click",()=>{v(f,!0),u.focus(),M()});document.querySelector("#close-search").addEventListener("click",()=>v(f,!1));document.querySelector("#open-sources").addEventListener("click",()=>v(P,!0));document.querySelector("#close-sources").addEventListener("click",()=>v(P,!1));u.addEventListener("input",()=>{z=u.value,M(z)});K.addEventListener("click",e=>{const t=e.target.closest("[data-place]");t&&(u.value=t.dataset.place??"",u.dispatchEvent(new Event("input")))});document.querySelectorAll(".map-place").forEach(e=>{const t=()=>{v(f,!0),u.value=e.dataset.place??"",u.dispatchEvent(new Event("input")),u.focus()};e.addEventListener("click",n=>{n.stopPropagation(),t()}),e.addEventListener("keydown",n=>{(n.key==="Enter"||n.key===" ")&&(n.preventDefault(),t())})});const X=document.querySelector(".map-svg"),x=document.querySelector("#map-lightbox"),A=document.querySelector("#lightbox-body");function U(){A.innerHTML="";const e=X.cloneNode(!0);e.removeAttribute("role"),e.setAttribute("aria-hidden","true"),e.querySelectorAll("[tabindex]").forEach(t=>t.removeAttribute("tabindex")),A.appendChild(e),x.classList.add("is-open"),x.setAttribute("aria-hidden","false"),document.body.classList.add("drawer-open")}function H(){x.classList.remove("is-open"),x.setAttribute("aria-hidden","true"),document.body.classList.remove("drawer-open")}X.addEventListener("click",e=>{e.target.closest(".map-place")||U()});document.querySelector("#expand-map").addEventListener("click",U);document.querySelector("#close-lightbox").addEventListener("click",H);x.addEventListener("click",e=>{(e.target===x||e.target===A)&&H()});document.querySelectorAll(".timeline-node").forEach(e=>e.addEventListener("click",()=>{d(Number(e.dataset.index)),j||$()}));document.querySelector("#toggle-play").addEventListener("click",e=>{const t=e.currentTarget,n=t.dataset.playing==="true";if(t.dataset.playing=String(!n),t.innerHTML=n?'<span class="play-icon">▶</span><span>播放</span>':'<span class="play-icon">Ⅱ</span><span>暂停</span>',!n){const p=window.setInterval(()=>{if(t.dataset.playing!=="true"||s>=i.length-1){window.clearInterval(p),t.dataset.playing="false",t.innerHTML='<span class="play-icon">▶</span><span>播放</span>';return}d(s+1)},2200)}});document.querySelector("#reset-timeline").addEventListener("click",()=>{const e=document.querySelector("#toggle-play");e.dataset.playing="false",e.innerHTML='<span class="play-icon">▶</span><span>播放</span>',d(0)});document.querySelectorAll(".model-tab").forEach(e=>e.addEventListener("click",()=>{document.querySelectorAll(".model-tab").forEach(t=>{t.classList.remove("is-active"),t.setAttribute("aria-selected","false")}),e.classList.add("is-active"),e.setAttribute("aria-selected","true"),document.querySelector("#model-copy").textContent=Q[e.dataset.model??"服制"]}));F.addEventListener("click",e=>{const t=e.target.closest("[data-place]");if(t){me(t.dataset.place??"");return}const n=e.target.closest("[data-locate]");if(!n)return;const p=n.dataset.locate??"";v(f,!1);const r=document.querySelector(`.map-place[data-place="${p}"]`);r&&(r.classList.remove("is-pulse"),r.offsetWidth,r.classList.add("is-pulse"),window.setTimeout(()=>r.classList.remove("is-pulse"),3600))});l.addEventListener("keydown",e=>{e.key==="ArrowRight"&&(e.preventDefault(),d(s+1)),e.key==="ArrowLeft"&&(e.preventDefault(),d(s-1)),e.key==="Home"&&(e.preventDefault(),d(0)),e.key==="End"&&(e.preventDefault(),d(i.length-1))});let C=!1;function W(e){const t=l.getBoundingClientRect(),n=Math.max(0,Math.min(1,(e-t.left)/t.width));d(Math.round(n*(i.length-1)))}l.addEventListener("pointerdown",e=>{C=!0,l.classList.add("is-dragging"),l.setPointerCapture(e.pointerId),W(e.clientX)});l.addEventListener("pointermove",e=>{C&&W(e.clientX)});l.addEventListener("pointerup",e=>{C=!1,l.classList.remove("is-dragging"),l.releasePointerCapture(e.pointerId)});l.addEventListener("pointercancel",()=>{C=!1,l.classList.remove("is-dragging")});document.addEventListener("keydown",e=>{(e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==="k"&&(e.preventDefault(),v(f,!0),u.focus(),M()),e.key==="Escape"&&(m.classList.remove("is-open"),m.setAttribute("aria-hidden","true"),P.classList.remove("is-open"),f.classList.remove("is-open"),document.body.classList.remove("drawer-open"),H())});document.querySelector(".brand").addEventListener("click",e=>{e.preventDefault(),Z.classList.remove("is-hidden"),G.classList.remove("is-visible"),j=!1});window.addEventListener("resize",()=>d(s));d(s);M();new URLSearchParams(window.location.search).get("stage")==="experience"&&$();
